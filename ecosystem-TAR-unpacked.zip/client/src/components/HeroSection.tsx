import { motion } from "framer-motion";
import AnimatedLogo from "./AnimatedLogo";

export default function HeroSection() {
  return (
    <div className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-gradient-to-b from-black via-cyan-900/20 to-background">
      {/* Animated hexagon background */}
      <div className="absolute inset-0">
        {[...Array(30)].map((_, i) => {
          const size = Math.random() * 40 + 20;
          return (
            <motion.div
              key={i}
              className="absolute"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                width: `${size}px`,
                height: `${size * 0.866}px`, // Для правильных пропорций шестиугольника
                background: `linear-gradient(45deg, rgba(6, 182, 212, 0.1), rgba(34, 211, 238, 0.2))`,
                clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)',
                border: '1px solid rgba(34, 211, 238, 0.3)',
              }}
              animate={{
                boxShadow: [
                  '0 0 5px rgba(34, 211, 238, 0.3)',
                  '0 0 20px rgba(34, 211, 238, 0.5)',
                  '0 0 5px rgba(34, 211, 238, 0.3)',
                ],
                opacity: [0.3, 0.6, 0.3],
              }}
              transition={{
                duration: Math.random() * 4 + 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          );
        })}
      </div>

      <div className="relative z-10 text-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <div className="flex justify-center mb-6">
            <AnimatedLogo />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-600 text-transparent bg-clip-text">
            Eco System TAR
          </h1>
          <p className="text-xl text-cyan-100 max-w-2xl mx-auto">
            Объединяем традиции и инновации через блокчейн-технологии
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col items-center space-y-2"
        >
          <div className="h-12 w-1 bg-gradient-to-b from-cyan-500 to-transparent" />
        </motion.div>
      </div>
    </div>
  );
}