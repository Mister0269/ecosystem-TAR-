import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { ArrowUpRight } from "lucide-react";

interface NewsCardProps {
  title: string;
  description: string;
  link: string;
}

export default function NewsCard({ title, description, link }: NewsCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <a href={link} target="_blank" rel="noopener noreferrer">
        <Card className="h-full p-6 bg-black/50 border-cyan-500/50 hover:border-cyan-500 transition-colors relative group overflow-hidden">
          {/* Неоновый эффект при наведении */}
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-600/10 to-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity" />

          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-600 text-transparent bg-clip-text">
                {title}
              </h3>
              <ArrowUpRight className="text-cyan-500 group-hover:text-cyan-400 transition-colors" />
            </div>

            <p className="text-cyan-100">{description}</p>
          </div>

          {/* Декоративная линия */}
          <div className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-cyan-500 to-blue-600 w-0 group-hover:w-full transition-all duration-300" />
        </Card>
      </a>
    </motion.div>
  );
}