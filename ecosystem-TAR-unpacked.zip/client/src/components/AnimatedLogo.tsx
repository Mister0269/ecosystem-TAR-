import { motion } from "framer-motion";

export default function AnimatedLogo() {
  // Генерируем точки для цифровых линий
  const generatePoints = (numPoints: number, radius: number, centerX: number, centerY: number) => {
    const points = [];
    for (let i = 0; i < numPoints; i++) {
      const angle = (i * 2 * Math.PI) / numPoints;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      points.push({ x, y, angle });
    }
    return points;
  };

  const centerPoints = generatePoints(12, 30, 100, 100);
  const outerPoints = generatePoints(12, 80, 100, 100);

  return (
    <div className="w-32 h-32 relative">
      <svg viewBox="0 0 200 200" className="w-full h-full">
        <defs>
          <linearGradient id="circleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#0891B2', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: '#0E7490', stopOpacity: 1 }} />
          </linearGradient>
        </defs>

        {/* Цифровые линии */}
        {centerPoints.map((innerPoint, i) => {
          const outerPoint = outerPoints[i];

          // Создаем промежуточные точки для "цифрового" эффекта
          const midX = innerPoint.x + (outerPoint.x - innerPoint.x) * 0.6;
          const midY = innerPoint.y + (outerPoint.y - innerPoint.y) * 0.6;

          // Добавляем небольшое смещение для создания углов
          const offsetX = Math.cos(innerPoint.angle + Math.PI/2) * 5;
          const offsetY = Math.sin(innerPoint.angle + Math.PI/2) * 5;

          return (
            <g key={i}>
              {/* Основная линия */}
              <motion.path
                d={`M ${innerPoint.x} ${innerPoint.y} 
                    L ${midX + offsetX} ${midY + offsetY} 
                    L ${midX - offsetX} ${midY - offsetY} 
                    L ${outerPoint.x} ${outerPoint.y}`}
                stroke="#22D3EE"
                strokeWidth="1.5"
                fill="none"
                initial={{ pathLength: 0, opacity: 0.3 }}
                animate={{
                  pathLength: [0, 1, 0],
                  opacity: [0.3, 0.8, 0.3],
                }}
                transition={{
                  duration: 3,
                  delay: i * 0.2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />

              {/* Точка на конце линии */}
              <motion.circle
                cx={outerPoint.x}
                cy={outerPoint.y}
                r="2"
                fill="#22D3EE"
                initial={{ scale: 0 }}
                animate={{
                  scale: [0, 1, 0],
                  opacity: [0.3, 1, 0.3],
                }}
                transition={{
                  duration: 3,
                  delay: i * 0.2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            </g>
          );
        })}

        {/* Центральный круг */}
        <motion.circle
          cx="100"
          cy="100"
          r="25"
          fill="url(#circleGradient)"
          stroke="#22D3EE"
          strokeWidth="2"
          initial={{ scale: 0.8 }}
          animate={{
            scale: [0.8, 1, 0.8],
            opacity: [0.8, 1, 0.8],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </svg>
    </div>
  );
}