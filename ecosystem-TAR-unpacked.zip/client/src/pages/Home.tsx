import HeroSection from "@/components/HeroSection";
import NewsCard from "@/components/NewsCard";
import { Card } from "@/components/ui/card";

const newsChannels = [
  {
    title: "Основной канал: Eco System TAR",
    description: "Платформа для развития экосистемы TAR",
    link: "https://t.me/ecosystemTAR",
  },
  {
    title: "Новостной канал Тыва Арат Республика",
    description: "Актуальные новости и обновления",
    link: "https://t.me/Tuvan_Peoples_Republic",
  },
  {
    title: "TSYBB AKSA",
    description: "Дорожная карта токена AKSA и все будущие проекты с токеном",
    link: "https://t.me/TSYBB_AKSA",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <HeroSection />

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {newsChannels.map((channel, index) => (
            <NewsCard
              key={index}
              title={channel.title}
              description={channel.description}
              link={channel.link}
            />
          ))}
        </div>

        <Card className="mt-16 p-6 bg-black/50 border-cyan-500/50">
          <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-blue-600 text-transparent bg-clip-text">
            О проекте Eco System TAR
          </h2>
          <p className="text-cyan-100 leading-relaxed">
            Eco System TAR - это инновационная платформа, объединяющая 
            традиционные ценности с современными блокчейн-технологиями,
            создавая уникальную экосистему для развития и роста.
          </p>
        </Card>
      </div>
    </div>
  );
}